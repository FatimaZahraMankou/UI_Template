using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public void OnPlayButtonClicked()
    {
        SceneManager.LoadScene("BattleScene");
    }

    public void OnExitButtonClicked()
    {
#if UNITY_EDITOR
            // Quitter le mode Play en mode �diteur
            UnityEditor.EditorApplication.isPlaying = false;
#else
        // Quitter l'application en build final
        Application.Quit();
#endif
    }
}
